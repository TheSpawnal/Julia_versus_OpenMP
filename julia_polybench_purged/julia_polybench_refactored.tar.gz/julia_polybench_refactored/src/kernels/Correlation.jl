module Correlation
const STRATEGIES_CORRELATION = ["sequential", "threads", "colmajor", "tiled"]
export STRATEGIES_CORRELATION
end
