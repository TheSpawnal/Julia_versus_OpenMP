module Cholesky
const STRATEGIES_CHOLESKY = ["sequential", "blocked", "blas"]
export STRATEGIES_CHOLESKY
end
