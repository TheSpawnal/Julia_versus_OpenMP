module Nussinov
const STRATEGIES_NUSSINOV = ["sequential", "simd", "wavefront", "tiled"]
export STRATEGIES_NUSSINOV
end
