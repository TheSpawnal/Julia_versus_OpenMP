module Jacobi2D
const STRATEGIES_JACOBI2D = ["sequential", "threads", "tiled", "redblack"]
export STRATEGIES_JACOBI2D
end
